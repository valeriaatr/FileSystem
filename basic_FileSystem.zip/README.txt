There are some compilation issues due structs' management.
Please, read report about FS implementation and brainstorming

1. 'make' (gives compilation errors anyway)
2. execute test1.c in /apps
3. output shows what it does