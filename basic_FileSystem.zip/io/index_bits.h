void init_buffer(unsigned char buffer[], int size);
void print_buffer(unsigned char buffer[], int size);
void set_block(unsigned char buffer[], int block_num);
void unset_block(unsigned char buffer[], int block_num);