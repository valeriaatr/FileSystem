void make_fs(int new);
//display content of a FS
//void list_fs();

//int open_file(char *name);

int write_file(int id, char fname,int size);

//int read_file(int id, char fname);

//int del_file(int id, char fname);

//int log();